﻿Public Class ScreenLoad

    Private Sub ScreenLoad_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        Timer1.Start()
        Timer1.Interval = 10
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(1)
        Label2.Text = Val(Label2.Text) + 1
        If (ProgressBar1.Value = 100) Then
            Timer1.Stop()
            Form1.Show()
            Me.Hide()
        End If

    End Sub
End Class