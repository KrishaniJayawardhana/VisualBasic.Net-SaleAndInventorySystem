﻿Imports MySql.Data.MySqlClient

Public Class StockForm
    Public con As New MySqlConnection("Server=localhost;  uid=root; pwd=''; database=saleinventory")
    Public cmd As New MySqlCommand
    Public dr As New MySqlDataAdapter
    Dim dss As New DataSet()

    Sub load()
        Dim Query As String = "select * from stock"
        dr = New MySqlDataAdapter(Query, con)
        dss = New DataSet
        dr.Fill(dss, "Emp1")
        DataGridView1.DataSource = dss.Tables(0)
        con.Close()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
    End Sub

    Public Sub StockForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        load()
    End Sub


    Private Sub DataGridView1_CellClick(ByVal Sender As Object, ByVal e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim row As DataGridViewRow = DataGridView1.CurrentRow
        Try
            TextBox1.Text = row.Cells(0).Value.ToString()
            TextBox2.Text = row.Cells(1).Value.ToString()
            TextBox3.Text = row.Cells(2).Value.ToString()
            TextBox4.Text = row.Cells(3).Value.ToString()
            TextBox5.Text = row.Cells(4).Value.ToString()

        Catch ex As Exception
            load()
        End Try
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        dss = New DataSet
        dr = New MySqlDataAdapter("insert into stock(sid,sname,sdesc,sprice,stock)Values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "')", con)
        dr.Fill(dss, "stock")
        MessageBox.Show("Record Added Successfully")

    End Sub

    
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        cmd = New MySqlCommand
        con.Open()
        Try
            cmd = con.CreateCommand()
            cmd.CommandText = "Update stock set sid=@sid, sname=@sname, sdesc=@sdesc, sprice=@sprice, stock=@stock"
            cmd.Parameters.AddWithValue("@sid", TextBox1.Text)
            cmd.Parameters.AddWithValue("@sname", TextBox2.Text)
            cmd.Parameters.AddWithValue("@sdesc", TextBox3.Text)
            cmd.Parameters.AddWithValue("@sprice", TextBox4.Text)
            cmd.Parameters.AddWithValue("@stock", TextBox5.Text)
            cmd.ExecuteNonQuery()
            load()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        cmd = New MySqlCommand
        con.Open()
        Try
            cmd.Connection.CreateCommand()
            cmd.CommandText = "delete from stock where sid=@sid;"
            cmd.Parameters.AddWithValue("@sid", TextBox1.Text)
            cmd.ExecuteNonQuery()
            load()
        Catch ex As Exception

        End Try
    End Sub
    End Sub
End Class