﻿Imports MySql.Data.MySqlClient


Public Class SignUp

    Public con As New MySqlConnection("Server=localhost;  uid=root; pwd=''; database=saleinventory")
    Public cmd As New MySqlCommand
    Public dr As New MySqlDataAdapter
    Dim dss As New DataSet()

    'Load the Database Tables Colom Names to DataGridView1 Table

    Sub load()
        Dim Query As String = "select * from signup"
        dr = New MySqlDataAdapter(Query, con)
        dss = New DataSet
        dr.Fill(dss, "Emp")
        DataGridView1.DataSource = dss.Tables(0)
        con.Close()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        TextBox6.Clear()
    End Sub

    'Load the DataGridView1 to SignUp Page

    Public Sub SignUp_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        load()
    End Sub

    Private Sub DataGridview1_CellClick(ByVal Sender As Object, ByVal e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim row As DataGridViewRow = DataGridView1.CurrentRow
        Try
            TextBox2.Text = row.Cells(0).Value.ToString()
            TextBox3.Text = row.Cells(1).Value.ToString()
            TextBox4.Text = row.Cells(2).Value.ToString()
            TextBox5.Text = row.Cells(3).Value.ToString()
            TextBox6.Text = row.Cells(4).Value.ToString()

        Catch ex As Exception
            load()
        End Try

    End Sub

    'Insert Data to Table'

    Public Sub submit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles submit.Click
        dss = New DataSet
        dr = New MySqlDataAdapter("insert into signup(FirstName,LastName,Position,UserName,Password)Values('" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "')", con)
        dr.Fill(dss, "signup")
        MessageBox.Show("Record Added Successfully")


    End Sub

    Private Sub update1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles update1.Click
        cmd = New MySqlCommand
        con.Open()
        Try
            cmd = con.CreateCommand()
            cmd.CommandText = "Update signup set FirstName=@FirstName, LastName=@LastName, Position=@Position, UserName=@UserName, Password=@Password"
            cmd.Parameters.AddWithValue("@FirstName", TextBox2.Text)
            cmd.Parameters.AddWithValue("@LastName", TextBox3.Text)
            cmd.Parameters.AddWithValue("@Position", TextBox4.Text)
            cmd.Parameters.AddWithValue("@UserName", TextBox5.Text)
            cmd.Parameters.AddWithValue("@Password", TextBox6.Text)
            cmd.ExecuteNonQuery()
            load()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles delete.Click
        cmd = New MySqlCommand
        con.Open()
        Try
            cmd.Connection.CreateCommand()
            cmd.CommandText = "delete from signup where FirstName=@FirstName;"
            cmd.Parameters.AddWithValue("@FirstName", TextBox2.Text)
            cmd.ExecuteNonQuery()
            load()
        Catch ex As Exception

        End Try
    End Sub
End Class

