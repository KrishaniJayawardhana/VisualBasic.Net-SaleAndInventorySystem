﻿
Class da

    Shared Sub Fill(ByVal dt As MySql.Data.MySqlClient.MySqlDataAdapter)
        Throw New NotImplementedException
    End Sub

End Class
