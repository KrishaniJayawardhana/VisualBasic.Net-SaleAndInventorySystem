﻿Imports MySql.Data.MySqlClient

Public Class Form1
    Public con As New MySqlConnection("Server=localhost;  uid=root; pwd=''; database=saleinventory")
    Public cmd As New MySqlCommand
    Public dr As New MySqlDataAdapter
    Dim ds As New DataSet()

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        SignUp.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        SaleForm.Show()
    End Sub
End Class
